int buildTree(Node *parent, Box *bounds, Node *particles, int N, int b);
void freeTree(Node *root);
