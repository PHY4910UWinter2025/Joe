Node *read_particles(char *fname, int *N, double *time);
void save_particles(Node * p, int N, double time, char *base);
