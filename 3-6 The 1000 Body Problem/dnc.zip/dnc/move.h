void AdvancePositions(Node *p, int N, float dt);
void AdvanceVelocities(Node *p, int N, float dt);
